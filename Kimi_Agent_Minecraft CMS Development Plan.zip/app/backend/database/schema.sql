-- Minecraft CMS Database Schema

CREATE DATABASE IF NOT EXISTS minecraft_cms DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE minecraft_cms;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    minecraft_username VARCHAR(50),
    avatar_url VARCHAR(255),
    balance DECIMAL(10, 2) DEFAULT 0.00,
    rank_id INT DEFAULT NULL,
    rank_expires_at DATETIME DEFAULT NULL,
    is_admin BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    email_verified BOOLEAN DEFAULT FALSE,
    last_login DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_email (email)
) ENGINE=InnoDB;

-- Categories Table
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    slug VARCHAR(50) NOT NULL UNIQUE,
    description TEXT,
    icon VARCHAR(50) DEFAULT 'Package',
    sort_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Products Table
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    category_id INT NOT NULL,
    image_url VARCHAR(255),
    stock INT DEFAULT -1,
    commands JSON NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    sort_order INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
    INDEX idx_category (category_id),
    INDEX idx_active (is_active)
) ENGINE=InnoDB;

-- Ranks Table
CREATE TABLE IF NOT EXISTS ranks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE,
    display_name VARCHAR(50) NOT NULL,
    description TEXT,
    price_monthly DECIMAL(10, 2) NOT NULL,
    price_yearly DECIMAL(10, 2),
    is_permanent BOOLEAN DEFAULT FALSE,
    price_permanent DECIMAL(10, 2),
    color VARCHAR(7) DEFAULT '#22c55e',
    icon VARCHAR(50) DEFAULT 'Crown',
    features JSON,
    permissions JSON,
    commands JSON,
    sort_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Orders Table
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_number VARCHAR(20) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    discount_amount DECIMAL(10, 2) DEFAULT 0.00,
    final_amount DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'processing', 'completed', 'failed', 'refunded') DEFAULT 'pending',
    payment_method VARCHAR(50),
    payment_id VARCHAR(100),
    ip_address VARCHAR(45),
    user_agent TEXT,
    completed_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user (user_id),
    INDEX idx_status (status),
    INDEX idx_created (created_at)
) ENGINE=InnoDB;

-- Order Items Table
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT,
    rank_id INT,
    item_type ENUM('product', 'rank') NOT NULL,
    item_name VARCHAR(100) NOT NULL,
    quantity INT DEFAULT 1,
    unit_price DECIMAL(10, 2) NOT NULL,
    total_price DECIMAL(10, 2) NOT NULL,
    commands_executed BOOLEAN DEFAULT FALSE,
    executed_at DATETIME,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL,
    FOREIGN KEY (rank_id) REFERENCES ranks(id) ON DELETE SET NULL,
    INDEX idx_order (order_id)
) ENGINE=InnoDB;

-- Announcements Table
CREATE TABLE IF NOT EXISTS announcements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    type ENUM('info', 'warning', 'success', 'danger') DEFAULT 'info',
    is_active BOOLEAN DEFAULT TRUE,
    show_until DATETIME,
    created_by INT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Server Settings Table
CREATE TABLE IF NOT EXISTS server_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(50) NOT NULL UNIQUE,
    setting_value TEXT,
    setting_group VARCHAR(50) DEFAULT 'general',
    is_public BOOLEAN DEFAULT TRUE,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Payment Methods Table
CREATE TABLE IF NOT EXISTS payment_methods (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    slug VARCHAR(50) NOT NULL UNIQUE,
    description TEXT,
    icon VARCHAR(50),
    config JSON,
    is_active BOOLEAN DEFAULT TRUE,
    sort_order INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Coupons Table
CREATE TABLE IF NOT EXISTS coupons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) NOT NULL UNIQUE,
    discount_type ENUM('percentage', 'fixed') DEFAULT 'percentage',
    discount_value DECIMAL(10, 2) NOT NULL,
    max_uses INT DEFAULT NULL,
    used_count INT DEFAULT 0,
    min_order_amount DECIMAL(10, 2) DEFAULT 0.00,
    valid_from DATETIME DEFAULT CURRENT_TIMESTAMP,
    valid_until DATETIME,
    is_active BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Activity Logs Table
CREATE TABLE IF NOT EXISTS activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action VARCHAR(50) NOT NULL,
    entity_type VARCHAR(50),
    entity_id INT,
    details JSON,
    ip_address VARCHAR(45),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_user (user_id),
    INDEX idx_action (action),
    INDEX idx_created (created_at)
) ENGINE=InnoDB;

-- Insert Default Data

-- Default Categories
INSERT INTO categories (name, slug, description, icon, sort_order) VALUES
('Eşyalar', 'items', 'Silahlar, zırhlar ve araçlar', 'Sword', 1),
('Bloklar', 'blocks', 'İnşaat malzemeleri ve bloklar', 'Box', 2),
('Kozmetik', 'cosmetics', 'Kostümler ve efektler', 'Sparkles', 3),
('Para', 'money', 'Oyun içi para birimleri', 'Coins', 4);

-- Default Ranks
INSERT INTO ranks (name, display_name, description, price_monthly, color, icon, features, permissions, commands) VALUES
('vip', 'VIP', 'Temel ayrıcalıklarla başlayın', 29.99, '#22c55e', 'Crown', 
 '["/fly komutu", "/hat komutu", "5 ev seti", "VIP sohbet kanalı", "Özel kuyruk efekti"]',
 '["essentials.fly", "essentials.hat", "essentials.sethome.multiple.5"]',
 '["lp user {player} parent add vip"]'),

('vip-plus', 'VIP+', 'Daha fazla ayrıcalık ve özellik', 59.99, '#3b82f6', 'Sparkles',
 '["Tüm VIP özellikleri", "/heal ve /feed komutları", "10 ev seti", "Özel kit (her 24 saat)", "Reklamsız deneyim", "Özel isim rengi"]',
 '["essentials.heal", "essentials.feed", "essentials.kit.vipplus"]',
 '["lp user {player} parent add vip-plus"]'),

('mvp', 'MVP', 'Premium deneyim için ideal', 99.99, '#a855f7', 'Shield',
 '["Tüm VIP+ özellikleri", "/gamemode komutu", "20 ev seti", "MVP kit (her 12 saat)", "Özel particle efektleri", "Öncelikli destek"]',
 '["essentials.gamemode", "essentials.kit.mvp", "particles.use"]',
 '["lp user {player} parent add mvp"]'),

('legend', 'LEGEND', 'Efsanevi bir deneyim!', 199.99, '#f59e0b', 'Star',
 '["Tüm MVP özellikleri", "/god modu", "Sınırsız ev seti", "Legend kit (her 6 saat)", "Tüm kozmetikler açık", "Admin panel erişimi", "Sunucu etkinliklerine öncelik"]',
 '["essentials.god", "essentials.kit.legend", "cosmetics.*"]',
 '["lp user {player} parent add legend"]');

-- Default Server Settings
INSERT INTO server_settings (setting_key, setting_value, setting_group, is_public) VALUES
('server_name', 'Minecraft CMS Sunucusu', 'general', 1),
('server_ip', 'play.minecraftcms.net', 'general', 1),
('server_version', '1.20.4', 'general', 1),
('max_players', '500', 'general', 1),
('discord_link', 'https://discord.gg/example', 'social', 1),
('shop_title', 'Minecraft CMS Mağazası', 'shop', 1),
('currency_symbol', 'TL', 'shop', 1),
('maintenance_mode', 'false', 'system', 0),
('rcon_host', 'localhost', 'minecraft', 0),
('rcon_port', '25575', 'minecraft', 0),
('rcon_password', '', 'minecraft', 0);

-- Default Payment Methods
INSERT INTO payment_methods (name, slug, description, icon, is_active, sort_order) VALUES
('Kredi Kartı', 'credit_card', 'Visa/Mastercard ile ödeme', 'CreditCard', 1, 1),
('Havale/EFT', 'bank_transfer', 'Banka havalesi ile ödeme', 'Building', 1, 2),
('Papara', 'papara', 'Papara ile hızlı ödeme', 'Wallet', 1, 3);

-- Default Admin User (password: admin123)
INSERT INTO users (username, email, password, minecraft_username, balance, is_admin, email_verified) VALUES
('admin', 'admin@minecraftcms.net', '$2a$10$YourHashedPasswordHere', 'AdminMC', 9999.99, 1, 1);
